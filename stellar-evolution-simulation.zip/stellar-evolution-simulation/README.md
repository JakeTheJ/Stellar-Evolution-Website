# Star Selector — Stellar Evolution Simulation (Task 2)

A mini simulation interface for the Ad Astra Induction Task. Pick a star
class and watch a circular "star" element smoothly transition in size and
color to match.

## Files

- `index.html` — page structure: the star element + 4 selector buttons
- `style.css` — space-themed styling, the star's circular gradient/glow, and
  the CSS transitions that animate size and color changes
- `script.js` — click handling; updates CSS custom properties on the star
  element based on the selected star type

## Star classes modeled

| Class         | Size          | Color              |
|---------------|---------------|--------------------|
| Red Dwarf     | small         | red                |
| Yellow Dwarf  | medium        | yellow-white       |
| Blue Giant    | medium-large  | cyan-blue          |
| Red Giant     | large         | orange-red         |

## Running it

Just open `index.html` in a browser — no build step or dependencies beyond
two Google Fonts loaded via CDN.
